import { Component, Inject } from '@angular/core';
import { Title, PubSubServiceContract } from 'microui-contracts';
import { FileMetadataService } from './filemetadata.service';
import { FileMetadataListing } from './filemetadatalisting.model';
import { SubCategories } from './filemetadatalisting.model';
import { FileMetadataModel } from './filemetadatalisting.model';
import { FileMetadata } from './filemetadata.model';
@Component({
    moduleId: module.id,
    selector: 'as-docpub',
    template: require('./docpub.component.html')
})
export class DocpubComponent {
    public expDate: String;
    public date: Date;
    public showErrorMsg: boolean;
    public fileMetadata: FileMetadata;
    public minExpDate: string;
    public filemetadatalisting: FileMetadataListing[];
    public subcategory: SubCategories[];
    public subJsonData: Object[];
    public category: FileMetadataListing[];
    public filemetadatamodel: FileMetadataModel[];
    public showfilelisting: Boolean;
    public fileUploadSuccess: number;
    public showRequiredCategoryMsg: Boolean;
    constructor(private pubsub: PubSubServiceContract, @Inject(Title) public title: string,
        private filemetadataService: FileMetadataService) {
        this.subcategory = [];
        this.filemetadatamodel = [];
        this.filemetadatalisting = [new FileMetadataListing(this.subcategory)];
        this.fileMetadata = new FileMetadata(new Date(), 0, 0, new Date(), 0, ' ', ' ', new Date(), 2, 1);
        this.minExpDate = new Date(new Date().setFullYear(new Date().getFullYear() + 1)).toISOString().split('T')[0];
        this.subcategory = [];
        this.category = [new FileMetadataListing(this.subcategory)];
        this.filemetadataService.getCategories().subscribe(res => this.category = res);
        this.fileUploadSuccess = 0;
        this.showRequiredCategoryMsg = false;
    }
    ngOnInit() {
        this.date = new Date();
        this.date.setFullYear(this.date.getFullYear() + 1);
        this.expDate = this.date.toISOString().split('T')[0];
    }
    changeSubCate(selectedCategory) {
        for (let x = 0; x < this.category.length; x++) {
            console.log(selectedCategory.target.value);
            if (this.category[x].id === Number(selectedCategory.target.value)) {
                console.log(this.category[x].subCategories);
                this.subJsonData = this.category[x].subCategories;
            }
        }
        console.log(this.subJsonData);
    }
    checkLength(name) {
        console.log(name.target.value);
        if (name.target.value && (name.target.value.toString().length >= 1)) {
            this.showErrorMsg = true;
            name.target.value = name.target.value.substring(0, 1);
        }
        if (name.target.value && (name.target.value.toString().length < 1)) {
            this.showErrorMsg = false;
        }
    }
    addFileMetaData() {
        let fileMetadata = FileMetadata.clone(this.fileMetadata);
        // if (this.validateForm(fileMetadata)) {
        this.filemetadataService.addFileMetaData(fileMetadata).subscribe(res => this.addSuccessfull(res));
        // }
    };
    addSuccessfull(createdFileMetadataId: number) {
        if (createdFileMetadataId > 0) { this.fileMetadata.clear(); this.fileUploadSuccess = createdFileMetadataId; }
        if (createdFileMetadataId < 0) { this.fileUploadSuccess = -1; }
    }
    getFileMetadatalisting(planname: string) {
        this.showfilelisting = true;
        this.filemetadataService.getFileMetadatalisting(planname).subscribe(res => this.filemetadatalisting = res.categories);
    };
    generateId(uniqueId: string) {
        return '#' + uniqueId;
    };
    /*validateForm(fileMetadata) {
        if (fileMetadata.fileName === ' ') {
            console.log('Empty');
        }
        if (fileMetadata.categoryId === 0) {
            this.showRequiredCategoryMsg = true;
        }
        if (fileMetadata.subCategoryId === 0) {
            console.log('Empty');
        }
    };*/
}
